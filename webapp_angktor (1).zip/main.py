
from flask import Flask, render_template, request, redirect, url_for, session
import json, os

app = Flask(__name__)
app.secret_key = 'angktor_secret'

DB_FILE = 'users.json'

def load_users():
    if not os.path.exists(DB_FILE):
        with open(DB_FILE, 'w') as f:
            json.dump({}, f)
    with open(DB_FILE, 'r') as f:
        return json.load(f)

def save_users(users):
    with open(DB_FILE, 'w') as f:
        json.dump(users, f)

@app.route('/')
def index():
    ref = request.args.get('ref')
    return redirect(f"https://t.me/angktor888bot?start={ref}" if ref else "https://t.me/angktor888bot")

@app.route('/home')
def home():
    username = request.args.get('user', 'Guest')
    users = load_users()
    if username not in users:
        users[username] = {"balance": 0, "referrals": 0}
        save_users(users)
    return render_template('home.html', username=username, balance=users[username]["balance"], referrals=users[username]["referrals"])

@app.route('/team')
def team():
    username = request.args.get('user', 'Guest')
    users = load_users()
    return render_template('team.html', username=username, referrals=users.get(username, {}).get("referrals", 0))

@app.route('/withdraw', methods=['GET', 'POST'])
def withdraw():
    username = request.args.get('user', 'Guest')
    users = load_users()
    if request.method == 'POST':
        amount = int(request.form['amount'])
        number = request.form['number']
        if users.get(username, {}).get("balance", 0) >= amount and amount >= 5:
            users[username]["balance"] -= amount
            save_users(users)
            return "تم إرسال طلب السحب، سيتم مراجعته ✅"
        else:
            return "الحد الأدنى للسحب 5 نقاط عن طريق محافظ الكاش فقط 🔥💝"
    return render_template('withdraw.html', username=username)

@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        if request.form['username'] == 'angktor' and request.form['password'] == '1Aa12345':
            session['admin'] = True
            return redirect('/admin/dashboard')
    return render_template('login.html')

@app.route('/admin/dashboard')
def admin_dashboard():
    if not session.get('admin'):
        return redirect('/admin')
    users = load_users()
    return render_template('admin.html', users=users)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=81)
